package com.example.assignment2

data class Student(
    val id: Int = 0,
    val name: String,
    val age: Int,
    val grade: String
)
